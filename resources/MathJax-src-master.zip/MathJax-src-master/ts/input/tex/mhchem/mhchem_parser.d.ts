export declare namespace mhchemParser {
  export function go(input: string, stateMachine: string): any[];
}

export declare namespace texify {
  export function go(input: any[], isInner?: boolean): string;
}
