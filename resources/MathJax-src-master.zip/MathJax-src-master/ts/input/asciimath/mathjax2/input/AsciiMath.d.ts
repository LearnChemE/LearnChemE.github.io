export var LegacyAsciiMath: any;
