import './lib/explorer.js';

import {combineDefaults} from '../../../../js/components/global.js';
import {ExplorerHandler} from '../../../../js/a11y/explorer.js';

if (MathJax.startup) {
  MathJax.startup.extendHandler(handler => ExplorerHandler(handler));
}
