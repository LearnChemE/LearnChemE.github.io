import {Loader} from '../../../js/components/loader.js';

Loader.preLoad(
  'loader', 'startup',
  'core',
  'input/mml',
  'output/chtml', 'output/chtml/fonts/tex.js',
  'ui/menu', 'a11y/assistive-mml'
);
