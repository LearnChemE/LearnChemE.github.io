import './lib/asciimath.js';

import {AsciiMath} from '../../../../js/input/asciimath.js';

if (MathJax.startup) {
  MathJax.startup.registerConstructor('asciimath', AsciiMath);
  MathJax.startup.useInput('asciimath');
}
