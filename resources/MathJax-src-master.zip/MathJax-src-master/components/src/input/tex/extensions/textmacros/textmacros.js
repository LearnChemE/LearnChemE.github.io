import './lib/textmacros.js';
