import './lib/colorv2.js';
import {rename} from '../rename.js';

rename('colorV2', 'colorv2', false);
