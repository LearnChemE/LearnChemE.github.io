import './lib/extpfeil.js';
