import './lib/configmacros.js';
import {rename} from '../rename.js';

rename('configMacros', 'configmacros', false);
