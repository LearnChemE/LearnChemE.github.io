import './lib/tex-base.js';

import {registerTeX} from '../tex/register.js';

registerTeX(['base']);

