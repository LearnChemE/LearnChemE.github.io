Trial code for LearnChemE & Bowman lab collaboration to improve reproducibility of light-induced processing

<!--
**AOsterbaan/AOsterbaan** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
-->
